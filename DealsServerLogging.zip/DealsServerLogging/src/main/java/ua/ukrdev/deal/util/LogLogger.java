package ua.ukrdev.deal.util;



import java.io.IOException;
import java.sql.SQLException;

public class LogLogger {



    public static void write()
            throws IOException,SQLException{




    }
}