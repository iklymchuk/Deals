package ua.ukrdev.deal.controller;

import java.io.IOException;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import ua.ukrdev.deal.form.User;
import ua.ukrdev.deal.service.UserService;

@Controller
@RequestMapping("/updateUser/{id}")
public class UpdateUser {
	
    @Autowired
    private UpdateValidation updateValidation;

	@Autowired
	private UserService userService;
	
	public void setUpdateValidation(
            UpdateValidation updateValidation) {
        this.updateValidation = updateValidation;
    }

	/*
    @RequestMapping(method = RequestMethod.GET)
    public String showUpdateForm(Map model) {
        User user = new User();
        model.put("user", user);
        return "updateUser";
    }
*/
	/*
	@RequestMapping(method = RequestMethod.GET)
		public ModelAndView editPage(@PathVariable Integer id) {
			ModelAndView modelAndView = new ModelAndView("updateUser");
			User user = userService.getUserById(id);
			modelAndView.addObject("user", user);
			return modelAndView;
	}
*/
	
	 @RequestMapping(method = RequestMethod.GET)
	    //public String showUpdate(@PathVariable Integer id, Map model) {
	    public String showUpdate(@RequestParam("user") User user, Map<String, Object> map,
                HttpServletRequest request) {

	       
		 //User user1 = userService.getUserById(id);
		 map.put("user", user);
		 map.put("userId", request.getParameter("id"));
		 
		 System.out.println("Name=" + user.getId() + " id=" + request.getParameter("user.id"));
		 
		 return "updateUser";
	 }

	@RequestMapping(method=RequestMethod.POST)
	public String processRegistration(@Valid User user,
            BindingResult result, Map<String, Object> map) throws IOException {

			user.setUsername("newUser21");
			user.setFname("newUser21");
			user.setLname("newUser21");
			user.setPassword("newUse21");
			user.setConfirmPassword("newUse2r1");
			user.setEmail("newUser21");
		
	        user.setIslock("0");
	     		
	     	userService.updateUser(user);
        
        return "index";
	}
	
}

