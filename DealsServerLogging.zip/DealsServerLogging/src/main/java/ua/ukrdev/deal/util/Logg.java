package ua.ukrdev.deal.util;

import org.apache.log4j.Logger;

/**
 * Created by Eugene on 22.09.2014.
 */

public  class Logg {
    static Logger log;



    public static void log(){
//         Logger log = Logg.getLogger(
//                Logg.class.getName());
    }
}
